package question1;

public class IllegalArgumentException extends Exception{
	
	private static final long serialVersionUID = -784443111113907669L;

	public IllegalArgumentException() {
		super();
	}

	public IllegalArgumentException(String message) {
		super(message);
	}


}
