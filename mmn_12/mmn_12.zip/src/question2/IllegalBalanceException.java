package question2;

public class IllegalBalanceException extends Exception {
	private static final long serialVersionUID = -8223380690698444937L;

	public IllegalBalanceException() {
		super();
	}

	public IllegalBalanceException(String message) {
		super(message);
	}
}
